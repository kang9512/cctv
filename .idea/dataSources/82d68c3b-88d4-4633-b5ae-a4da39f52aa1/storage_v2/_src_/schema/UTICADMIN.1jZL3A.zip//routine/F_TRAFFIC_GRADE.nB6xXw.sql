create FUNCTION F_TRAFFIC_GRADE( vLinkID  IN VARCHAR2 ,Speed IN NUMBER) 
  RETURN CHAR IS lsReturn CHAR(2) ;

BEGIN
	SELECT TRAFFICGRADE 
	  INTO lsReturn
	  FROM LINK a, TRAFFICGRADE b
	 WHERE a.LinkID > ' '
	   AND LINKID = vLinkID
	   AND a.ROADRANK = b.ROADRANK
	   AND b.MINSPEED <= Speed
	   AND b.MAXSPEED >= Speed;
RETURN lsReturn;

exception when others then
   return  '99';

END;

/

