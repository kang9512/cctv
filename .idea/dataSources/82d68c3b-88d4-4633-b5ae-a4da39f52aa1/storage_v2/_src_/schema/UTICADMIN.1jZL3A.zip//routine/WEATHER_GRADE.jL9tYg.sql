create FUNCTION WEATHER_GRADE
    (pop IN NUMBER
    ,pty IN NUMBER
    ,rn IN NUMBER
    ,sw IN NUMBER
    ,tm IN NUMBER)
    RETURN VARCHAR
IS
    grade VARCHAR2(4 BYTE);
BEGIN
    IF pop >= 70 THEN
        CASE pty
        WHEN 0 THEN
            grade := 'N';
        WHEN 1 THEN
            IF rn < 2 THEN
                grade := 'a';
            ELSIF rn >= 2 AND rn < 110 THEN
                grade := 'A';
            ELSIF rn >= 110 THEN
                grade := 'B';
            END IF;
        WHEN 2 THEN
            IF tm <= 0 THEN
                grade := 'C_1';
            ELSE
                grade := 'C_2';
            END IF;
        WHEN 3 THEN
            IF sw < 2 THEN
                IF tm >= 0 THEN
                    grade := 'E';
                ELSE
                    grade := 'D';
                END IF;
            ELSE
                grade := 'F';
            END IF;
        ELSE grade := 'N';
        END CASE;    
    ELSE
        grade := 'N';
    END IF;
RETURN grade;
END;

/

