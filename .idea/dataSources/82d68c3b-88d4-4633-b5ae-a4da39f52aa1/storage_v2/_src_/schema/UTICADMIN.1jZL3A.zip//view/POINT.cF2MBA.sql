create view POINT as
SELECT DISTINCT (POINT_NUM) CCTV_NUM,
                   NEW_NUM,
                   ON_OFF,
                   NAME_KO,
                   SYSDATE COLLDT
     FROM spacctv.point@spaticdb
    WHERE POINT_NUM < 592
/

