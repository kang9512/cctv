create function TIME_INTERVAL (
NOEWDATE in VARCHAR2, PASTDATE in VARCHAR2)
return number is rv number;
begin
SELECT ROUND((TO_DATE(NOEWDATE, 'YYYYMMDDHH24MISS') -
       TO_DATE(PASTDATE, 'YYYYMMDDHH24MISS')) * 1440/5) * 5
       INTO rv
  FROM DUAL;
return rv;
end;

/

